---
title: Redis HyperLogLog及应用尝试
author: 小黄鸭
type: post
date: 2019-10-16T05:02:48+00:00
excerpt: 了解一下6年前Redis引入的“新”数据结构——HyperLogLog，高效的概率计数、去重利器。
featured_image: /wp-content/uploads/2019/10/hll.png
rank_math_primary_category:
  - 14
rank_math_seo_score:
  - 10
rank_math_internal_links_processed:
  - 1
categories:
  - 消息队列/中间件
tags:
  - HyperLogLog
  - Redis
  - 去重
  - 计数

---
WIP!